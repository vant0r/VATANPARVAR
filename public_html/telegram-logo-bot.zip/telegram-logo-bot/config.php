<?php
define('BOT_TOKEN', 'BOTFATHERDAN_OLGAN_TOKEN');
define('API_URL', 'https://api.telegram.org/bot' . BOT_TOKEN . '/');
define('FILE_URL', 'https://api.telegram.org/file/bot' . BOT_TOKEN . '/');
define('LOGO_PATH', __DIR__ . '/logo.png');
define('TMP_DIR', __DIR__ . '/tmp');
